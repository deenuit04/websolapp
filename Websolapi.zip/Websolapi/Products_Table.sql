﻿CREATE TABLE [dbo].[Products]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[Name] NVARCHAR(255),
	[Description] NVARCHAR(2500)
)

INSERT INTO Products (Id, Name, Description) VALUES (1, 'Visual Studio', 'Visual Studio 2019')
INSERT INTO Products (Id, Name, Description) VALUES (2, 'SharePoint Online', 'SharePoint Online in o365')
INSERT INTO Products (Id, Name, Description) VALUES (3, 'Windows Server', 'Windows Server 2016')
INSERT INTO Products (Id, Name, Description) VALUES (4, 'SQL Server', 'SQL Server 2019')
INSERT INTO Products (Id, Name, Description) VALUES (5, 'Azure', 'MIcrosoft Cloud subscription')