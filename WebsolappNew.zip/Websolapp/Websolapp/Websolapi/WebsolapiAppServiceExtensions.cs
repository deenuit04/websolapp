﻿using System;
using System.Net.Http;
using Microsoft.Azure.AppService;

namespace Websolapp
{
    public static class WebsolapiAppServiceExtensions
    {
        public static Websolapi CreateWebsolapi(this IAppServiceClient client)
        {
            return new Websolapi(client.CreateHandler());
        }

        public static Websolapi CreateWebsolapi(this IAppServiceClient client, params DelegatingHandler[] handlers)
        {
            return new Websolapi(client.CreateHandler(handlers));
        }

        public static Websolapi CreateWebsolapi(this IAppServiceClient client, Uri uri, params DelegatingHandler[] handlers)
        {
            return new Websolapi(uri, client.CreateHandler(handlers));
        }

        public static Websolapi CreateWebsolapi(this IAppServiceClient client, HttpClientHandler rootHandler, params DelegatingHandler[] handlers)
        {
            return new Websolapi(rootHandler, client.CreateHandler(handlers));
        }
    }
}
